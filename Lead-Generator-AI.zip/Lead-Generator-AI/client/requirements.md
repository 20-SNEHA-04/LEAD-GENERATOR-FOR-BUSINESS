## Packages
framer-motion | Smooth entry animations and micro-interactions for a premium feel
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes without conflicts

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
