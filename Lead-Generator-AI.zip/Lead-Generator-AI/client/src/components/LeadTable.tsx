import { motion } from "framer-motion";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Phone, MapPin, CheckCircle2, AlertCircle } from "lucide-react";
import type { Lead } from "@shared/schema";

interface LeadTableProps {
  leads: Lead[];
  isLoading?: boolean;
}

export function LeadTable({ leads, isLoading }: LeadTableProps) {
  if (isLoading) {
    return (
      <div className="w-full space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-16 w-full bg-muted/50 rounded-lg animate-pulse" />
        ))}
      </div>
    );
  }

  if (leads.length === 0) {
    return (
      <div className="text-center py-20 px-4 border-2 border-dashed border-border rounded-xl bg-card/50">
        <div className="bg-muted w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertCircle className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-xl font-bold text-foreground">No leads generated yet</h3>
        <p className="text-muted-foreground mt-2 max-w-sm mx-auto">
          Enter a location and niche above to start generating verified business leads.
        </p>
      </div>
    );
  }

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="rounded-xl border border-border overflow-hidden bg-card shadow-lg shadow-black/5">
      <Table>
        <TableHeader className="bg-muted/50">
          <TableRow>
            <TableHead className="w-[80px] font-bold">Rank</TableHead>
            <TableHead className="font-bold">Business Name</TableHead>
            <TableHead className="font-bold">Contact Info</TableHead>
            <TableHead className="font-bold">Location</TableHead>
            <TableHead className="w-[150px] font-bold text-right">Status</TableHead>
          </TableRow>
        </TableHeader>
        <motion.tbody
          variants={container}
          initial="hidden"
          animate="show"
          className="[&_tr:last-child]:border-0"
        >
          {leads.map((lead) => (
            <motion.tr
              key={lead.id}
              variants={item}
              className="border-b transition-colors hover:bg-muted/30 data-[state=selected]:bg-muted"
            >
              <TableCell className="font-medium">
                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-display font-bold">
                  {lead.rank}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex flex-col">
                  <span className="font-bold text-base text-foreground">{lead.businessName}</span>
                  <a 
                    href={lead.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center text-sm text-primary hover:underline mt-0.5 w-fit"
                  >
                    Visit Website <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                </div>
              </TableCell>
              <TableCell>
                <div className="flex items-center text-muted-foreground">
                  <Phone className="w-4 h-4 mr-2 text-muted-foreground/70" />
                  <span className="font-medium">{lead.phone}</span>
                </div>
              </TableCell>
              <TableCell>
                <div className="flex items-center text-muted-foreground max-w-[200px]">
                  <MapPin className="w-4 h-4 mr-2 shrink-0 text-muted-foreground/70" />
                  <span className="truncate" title={lead.address}>{lead.address}</span>
                </div>
              </TableCell>
              <TableCell className="text-right">
                <Badge 
                  variant={lead.verificationStatus === 'Verified' ? 'default' : 'secondary'}
                  className={`
                    ${lead.verificationStatus === 'Verified' 
                      ? 'bg-green-100 text-green-700 hover:bg-green-100 border-green-200' 
                      : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100 border-yellow-200'
                    }
                  `}
                >
                  {lead.verificationStatus === 'Verified' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                  {lead.verificationStatus}
                </Badge>
              </TableCell>
            </motion.tr>
          ))}
        </motion.tbody>
      </Table>
    </div>
  );
}
