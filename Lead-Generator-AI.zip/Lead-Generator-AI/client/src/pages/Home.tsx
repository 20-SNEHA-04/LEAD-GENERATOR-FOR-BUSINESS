import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useGenerateLeads, useLeads } from "@/hooks/use-leads";
import { api, type GenerateLeadsInput } from "@shared/routes";
import { LeadTable } from "@/components/LeadTable";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Loader2, Search, MapPin, Briefcase } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const [hasSearched, setHasSearched] = useState(false);
  const generateLeads = useGenerateLeads();
  const { data: historyLeads } = useLeads(); // Optional: could show history if needed

  // If we have just generated leads, show those. Otherwise fallback to empty array.
  const displayLeads = generateLeads.data || [];

  const form = useForm<GenerateLeadsInput>({
    resolver: zodResolver(api.leads.generate.input),
    defaultValues: {
      location: "",
      niche: "",
    },
  });

  const onSubmit = (data: GenerateLeadsInput) => {
    setHasSearched(true);
    generateLeads.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden font-sans">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-blue-50 to-transparent dark:from-blue-950/20 -z-10 pointer-events-none" />
      <div className="absolute top-[-100px] right-[-100px] w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-0 left-[-200px] w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl -z-10" />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
        
        {/* Hero Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16 space-y-6"
        >
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-2">
            <span className="relative flex h-2 w-2 mr-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            AI-Powered Lead Generation V1.0
          </div>
          
          <h1 className="text-4xl md:text-6xl font-display font-bold tracking-tight text-foreground leading-tight">
            Find Your Next Customer <br />
            <span className="text-gradient">In Seconds, Not Hours</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Generate verified business leads based on specific niches and locations. 
            Our AI engine ranks potential clients so you can focus on closing deals.
          </p>
        </motion.div>

        {/* Search Form Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="max-w-4xl mx-auto mb-16 relative z-10"
        >
          <Card className="border-border/50 shadow-2xl shadow-primary/5 bg-white/80 dark:bg-card/80 backdrop-blur-xl">
            <CardContent className="p-6 md:p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col md:flex-row gap-4 items-end">
                  
                  <div className="flex-1 w-full">
                    <FormField
                      control={form.control}
                      name="niche"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold ml-1">Business Niche</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Briefcase className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                              <Input 
                                placeholder="e.g. Plumbers, Digital Agencies..." 
                                className="pl-10 h-12 text-lg input-premium bg-background/50" 
                                {...field} 
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex-1 w-full">
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold ml-1">Target Location</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <MapPin className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                              <Input 
                                placeholder="e.g. San Francisco, CA" 
                                className="pl-10 h-12 text-lg input-premium bg-background/50" 
                                {...field} 
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button 
                    type="submit" 
                    size="lg" 
                    disabled={generateLeads.isPending}
                    className="w-full md:w-auto h-12 px-8 text-base font-bold shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all hover:-translate-y-0.5"
                  >
                    {generateLeads.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Search className="mr-2 h-5 w-5" />
                        Generate Leads
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </motion.div>

        {/* Results Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="max-w-6xl mx-auto"
        >
          {hasSearched && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-display font-bold text-foreground">
                  Generated Results
                  {displayLeads.length > 0 && (
                    <span className="ml-3 text-sm font-sans font-medium bg-muted px-3 py-1 rounded-full text-muted-foreground">
                      {displayLeads.length} leads found
                    </span>
                  )}
                </h2>
                {generateLeads.isPending && (
                  <span className="text-sm text-primary animate-pulse font-medium">
                    AI is analyzing local businesses...
                  </span>
                )}
              </div>
              
              <LeadTable 
                leads={displayLeads} 
                isLoading={generateLeads.isPending} 
              />
            </div>
          )}

          {/* Optional: Show recent history if user hasn't searched yet and there's history */}
          {!hasSearched && historyLeads && historyLeads.length > 0 && (
            <div className="space-y-6 opacity-60 hover:opacity-100 transition-opacity duration-300">
              <div className="flex items-center justify-between">
                 <h2 className="text-2xl font-display font-bold text-foreground">Recently Generated</h2>
              </div>
              <LeadTable leads={historyLeads.slice(0, 5)} />
            </div>
          )}

        </motion.div>

      </main>
    </div>
  );
}
