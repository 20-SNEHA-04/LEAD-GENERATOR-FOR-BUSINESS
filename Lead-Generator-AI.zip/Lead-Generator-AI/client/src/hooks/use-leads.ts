import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type GenerateLeadsInput } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useLeads() {
  return useQuery({
    queryKey: [api.leads.list.path],
    queryFn: async () => {
      const res = await fetch(api.leads.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch leads");
      return api.leads.list.responses[200].parse(await res.json());
    },
  });
}

export function useGenerateLeads() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: GenerateLeadsInput) => {
      const res = await fetch(api.leads.generate.path, {
        method: api.leads.generate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.leads.generate.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        if (res.status === 500) {
          const error = api.leads.generate.responses[500].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to generate leads");
      }

      return api.leads.generate.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      // Invalidate the list query to show new leads if they are persisted
      queryClient.invalidateQueries({ queryKey: [api.leads.list.path] });
      
      toast({
        title: "Leads Generated Successfully",
        description: `Found ${data.length} verified businesses in your niche.`,
        variant: "default",
        className: "bg-green-50 border-green-200 text-green-900",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
