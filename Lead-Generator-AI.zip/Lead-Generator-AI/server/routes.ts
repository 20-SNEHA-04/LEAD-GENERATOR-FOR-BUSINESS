import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post(api.leads.generate.path, async (req, res) => {
    try {
      const { niche, location } = api.leads.generate.input.parse(req.body);

      // Call OpenAI to generate leads
      const prompt = `Generate 5 realistic business leads for the niche '${niche}' in '${location}'. 
      For each lead, provide the following fields:
      - business_name
      - address
      - phone (fake but realistic format)
      - website (fake but realistic URL)
      - verification_status (Randomly assign 'Verified' or 'Unverified')
      - rank (1 to 5, where 1 is best)
      
      Return ONLY valid JSON in the following format:
      {
        "leads": [
          { "business_name": "...", "address": "...", "phone": "...", "website": "...", "verification_status": "...", "rank": 1 }
        ]
      }`;

      const response = await openai.chat.completions.create({
        model: "gpt-5.2", // Using the best model available as per blueprint
        messages: [
          { role: "system", content: "You are a helpful business lead generator. You output only valid JSON." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
      });

      const content = response.choices[0].message.content;
      if (!content) {
        throw new Error("No content received from AI");
      }

      const parsed = JSON.parse(content);
      const generatedLeads = parsed.leads || [];

      // Map to InsertLead type
      const leadsToInsert = generatedLeads.map((l: any) => ({
        businessName: l.business_name,
        address: l.address,
        phone: l.phone,
        website: l.website,
        niche: niche,
        location: location,
        verificationStatus: l.verification_status,
        rank: l.rank,
      }));

      // Store in DB (optional, but fulfilling storage contract)
      const storedLeads = await storage.createLeads(leadsToInsert);

      res.json(storedLeads);
    } catch (err) {
      console.error("Error generating leads:", err);
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      } else {
        res.status(500).json({ message: "Failed to generate leads" });
      }
    }
  });

  app.get(api.leads.list.path, async (req, res) => {
    const leads = await storage.getLeads();
    res.json(leads);
  });

  return httpServer;
}
