import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  businessName: text("business_name").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  website: text("website").notNull(),
  niche: text("niche").notNull(),
  location: text("location").notNull(),
  verificationStatus: text("verification_status").notNull(), // "Verified" | "Unverified"
  rank: integer("rank").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLeadSchema = createInsertSchema(leads).omit({ id: true, createdAt: true });

export type Lead = typeof leads.$inferSelect;
export type InsertLead = z.infer<typeof insertLeadSchema>;

export const generateLeadsSchema = z.object({
  niche: z.string().min(1, "Niche is required"),
  location: z.string().min(1, "Location is required"),
});

export type GenerateLeadsRequest = z.infer<typeof generateLeadsSchema>;
